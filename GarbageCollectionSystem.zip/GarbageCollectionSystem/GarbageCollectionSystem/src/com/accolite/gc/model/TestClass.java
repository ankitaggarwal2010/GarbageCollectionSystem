package com.accolite.gc.model;

public class TestClass {

}
